create view LIBRARIES as
select (`cat`.`name` collate utf8mb3_tolower_ci) AS `LIBRARY_CATALOG`,
       (`sch`.`name` collate utf8mb3_tolower_ci) AS `LIBRARY_SCHEMA`,
       `rtn`.`name`                              AS `LIBRARY_NAME`,
       if(can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, true), `rtn`.`definition_utf8`,
          NULL)                                  AS `LIBRARY_DEFINITION`,
       `rtn`.`external_language`                 AS `LANGUAGE`,
       `rtn`.`created`                           AS `CREATED`,
       `rtn`.`last_altered`                      AS `LAST_ALTERED`,
       `rtn`.`sql_mode`                          AS `SQL_MODE`,
       `rtn`.`definer`                           AS `CREATOR`
from ((`mysql`.`routines` `rtn` join `mysql`.`schemata` `sch`
       on ((`rtn`.`schema_id` = `sch`.`id`))) join `mysql`.`catalogs` `cat` on ((`cat`.`id` = `sch`.`catalog_id`)))
where ((0 <> can_access_routine(`sch`.`name`, `rtn`.`name`, `rtn`.`type`, `rtn`.`definer`, false)) and
       (`rtn`.`type` = 'LIBRARY'));

